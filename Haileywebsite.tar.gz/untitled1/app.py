from flask import Flask, request, make_response, render_template

app = Flask(__name__)


@app.route('/')
def home():
    return make_response(render_template("Home.html"))


@app.route('/app')
def application():
    return make_response(render_template("application.html"))


@app.route('/results')
def results():
    return make_response(render_template("results.html"))


@app.route('/disclaimer')
def disclaimer():
    gourd_names = open("/home/theox/Documents/School/course8a/names.txt", "r", encoding="ISO-8859-1")
    compound_names = open("/home/theox/Documents/School/course8a/compounds.txt", "r", encoding="ISO-8859-1")
    disease_names = open("/home/theox/Documents/School/course8a/diseases.txt", "r", encoding="ISO-8859-1")
    return make_response(render_template("disclaimer.html", gourd_names=(gourd_names.readlines()), compound_names=(compound_names.readlines()), disease_names=(disease_names.readlines())))


if __name__ == '__main__':
    app.run()
